You can add your scripted files simply adding new text files 
with extension ".csv" in this folder.
When bot load it read csv files list and populate combo fields
with new scripted attack algorithms.
 
The fastest method to create new scripted files it is to 
duplicate an existing script and  edit with a txt editor 
like "notepad".
